//
//  AsgViewController.m
//  Assignment1
//
//  Created by Steven on 13-11-25.
//  Copyright (c) 2013年 Steven. All rights reserved.
//

#import "AsgViewController.h"
#import "AsgChecker.h"

@interface AsgViewController ()

@property (weak, nonatomic) IBOutlet UITextField *Year_textfield;
@property (weak, nonatomic) IBOutlet UILabel *Yes_or_No_Label;
@property (weak, nonatomic) IBOutlet UIButton *Click_Button;


@end

@implementation AsgViewController

- (IBAction)Action:(id)sender
{
    NSString *num= self.Year_textfield.text;
    NSError* __autoreleasing error=nil;
    
    BOOL result=[AsgChecker isLeapYear:[num integerValue]   error:&error];
    
    if(result==YES)
    {
        self.Yes_or_No_Label.text=NSLocalizedString(@"is a leap year", @"是闰年！");
    }
    else
    {
        self.Yes_or_No_Label.text=NSLocalizedString(@"is not a leap year", @"不是闰年！");
    }
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
