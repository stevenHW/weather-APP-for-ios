//
//  main.m
//  Assignment1
//
//  Created by Steven on 13-11-25.
//  Copyright (c) 2013年 Steven. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AsgAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AsgAppDelegate class]));
    }
}
