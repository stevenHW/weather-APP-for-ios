//
//  AsgChecker.h
//  Assignment1
//
//  Created by Steven on 13-11-25.
//  Copyright (c) 2013年 Steven. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AsgChecker : NSObject

+ (BOOL)isLeapYear:(NSInteger)year error:(NSError**)error;


@end
