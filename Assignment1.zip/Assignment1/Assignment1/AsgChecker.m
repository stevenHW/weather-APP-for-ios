//
//  AsgChecker.m
//  Assignment1
//
//  Created by Steven on 13-11-25.
//  Copyright (c) 2013年 Steven. All rights reserved.
//

#import "AsgChecker.h"

@implementation AsgChecker

+ (BOOL)isLeapYear:(NSInteger)year error:(NSError**)error
{
    BOOL Flag=NO;
    if (year>=0&&year<=9999)
    {
        
    
        if(year%4==0)
        {
            Flag=YES;
        }
    
        else
        {
            if (year%100==0&&year%400==0)
            {
                Flag=YES;
            }
            else
                Flag=NO;
        }
    
        return Flag;
    }
    else
        return Flag;
    
}

+ (int)test :(NSInteger) num1
{
    
    return 0;
}



@end
