//
//  ASGViewController.m
//  Assignment2
//
//  Created by Steven on 13-11-28.
//  Copyright (c) 2013年 Steven. All rights reserved.
//

#import "ASGViewController.h"

@interface ASGViewController () {
    NSInteger _imageIndex;
    NSArray *_piorConstrains;
    NSArray *_containerConstrains;
    CGRect _containerViewFrame;
    CGFloat _springDamping;
    CGFloat _springVelocity;
    
}

@property (weak, nonatomic) IBOutlet UIImageView *container;
@property (strong, nonatomic) IBOutlet UIImageView *frontview;
@property (strong, nonatomic) IBOutlet UIImageView *backview;

@end

@implementation ASGViewController


- (IBAction)controlEyes:(id)sender
{
    UISwitch * swicher=(UISwitch*) sender;
//    
//    _imageIndex=1;
//    
//    if (swicher.isOn==NO)
//    {
//            self.container.image=[UIImage imageNamed:@"HappyFaceCloseEyes"];
//       _imageIndex=0;
//    }
//     else
//     {
//         self.container.image=[UIImage imageNamed:@"HappyFaceOpenEyes"];
//        _imageIndex=1;
//     }
   // NSLog(@"eyesSwitchAction:value=%d",[sender isOn]);
//    if ([self.frontview superview]==nil) {
//        return;
//    }
//    else
//    {
        if (swicher.isOn==YES) {
            self.frontview.image=[UIImage imageNamed:@"HappyFaceOpenEyes"];
        }
        else
        {
            self.frontview.image=[UIImage imageNamed:@"HappyFaceCloseEyes"];
        }
 //   }
}

- (NSArray *)constrainSubview:(UIView *)subview toMatchWithSuperview: (UIView *)superview
{
    subview.translatesAutoresizingMaskIntoConstraints=NO;
    NSDictionary *viewDictionary=NSDictionaryOfVariableBindings(subview);
    
    NSArray *contraints =[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[subview]|"
                                                                 options:0
                                                                 metrics:nil
                                                                   views:viewDictionary];
    
    contraints= [contraints arrayByAddingObjectsFromArray:
                 [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[subview]|"
                                                        options:0
                                                        metrics:nil
                                                        views:viewDictionary]];
    [superview addConstraints:contraints];
    return contraints;
}


- (IBAction)controlBack:(id)sender
{
//   // //_imageIndex=1;
//    UISwitch * switcher=(UISwitch*) sender;
//    if (switcher.isOn==NO) {
//        self.container.image=[UIImage imageNamed:@"HappyFaceBack"];
//    }
//    else
//    {
//        if (_imageIndex==1) {
//            self.container.image=[UIImage imageNamed:@"HappyFaceOpenEyes"];
//        }
//        else
//            self.container.image=[UIImage imageNamed:@"HappyFaceCloseEyes"];
//    }
    UIViewAnimationOptions transtionOptions=([self.frontview superclass] ) ? UIViewAnimationOptionTransitionFlipFromRight:
         UIViewAnimationOptionTransitionFlipFromLeft;
    [self performTransition:transtionOptions];
}

- (void) performTransition:(UIViewAnimationOptions) options
{
    UIView * frontView, *toView;
    if ([self.frontview superview]!=nil) {
        frontView=self.frontview;
        toView=self.backview;
    }
    else
    {
        frontView=self.backview;
        toView=self.frontview;
    }
    NSArray *priorConstrains=_piorConstrains;
    [UIView transitionFromView:frontView  toView:toView duration:1.0 options:options completion:^(BOOL finished) {
        if(priorConstrains!=nil)
        {
            [self.container removeConstraints:priorConstrains];
        }
    }];
    _piorConstrains=[self constrainSubview: toView toMatchWithSuperview: self.container];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _imageIndex=1;
	// Do any additional setup after loading the view, typically from a nib.
    [self.container addSubview:self.frontview];
    _piorConstrains=[self constrainSubview:self.frontview toMatchWithSuperview:self.container];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
