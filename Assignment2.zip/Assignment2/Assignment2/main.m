//
//  main.m
//  Assignment2
//
//  Created by Steven on 13-11-28.
//  Copyright (c) 2013年 Steven. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ASGAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ASGAppDelegate class]));
    }
}
